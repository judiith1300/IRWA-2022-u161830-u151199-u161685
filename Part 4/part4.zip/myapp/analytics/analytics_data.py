import json
import random


class AnalyticsData:
    """
    An in memory persistence object.
    Declare more variables to hold analytics tables.
    """
    # statistics table 1
    # fact_clicks is a dictionary with the click counters: key = doc id | value = click counter
    fact_clicks = dict([])

    # statistics table 2
    fact_query = dict([])

    # statistics table 3
    fact_ranking = dict([])

    def save_query_terms(self, terms: str) -> int:
        print(self)
        return random.randint(0, 100000)

    def add_query_to_doc(self, doc_id, query):
        if doc_id not in self.fact_query:
            self.fact_query[doc_id] = [query]
        else:
            self.fact_query[doc_id].append(query)

    def add_ranking_to_doc(self, doc_id, ranking):
        if doc_id not in self.fact_ranking:
            self.fact_ranking[doc_id] = [ranking]
        else:
            self.fact_ranking[doc_id].append(ranking)

class Agent_data:
    def __init__(self, request):
        self.platform = request.user_agent.platform
        self.browser = request.user_agent.browser
        self.language = request.user_agent.language

class ClickedDoc:
    def __init__(self, doc_id, description, counter):
        self.doc_id = doc_id
        self.description = description
        self.counter = counter

    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
