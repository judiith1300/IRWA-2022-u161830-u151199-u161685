from collections import defaultdict
from array import array
from myapp.search.load_corpus import build_terms
import math
from numpy import linalg as la
import numpy as np
import collections


def create_tfidf(corpus):
    """
    Implement the inverted index and compute tf, df and idf
    
    Argument:
    corpus -- dataframe of tweets
    
    Returns:
    tf - normalized term frequency for each term in each document
    idf - inverse document frequency of each term
    """

    num_documents = len(corpus.index)
    lines = corpus

    tf = defaultdict(list)  # term frequencies of terms in documents (documents in the same order as in the main index)
    df = defaultdict(int)  # document frequencies of terms in the corpus
    idf = defaultdict(float)

    for doc,terms in zip(lines['Id'].values, lines['processed_text'].values):
        ## ===============================================================        
        ## create the index for the **current page** and store it in current_page_index
        ## current_page_index ==> { ‘term1’: [current_doc, [list of positions]], ...,‘term_n’: [current_doc, [list of positions]]}
        ## ===============================================================

        current_page_index = {}

        for position, term in enumerate(terms):  ## terms contains page_title + page_text
            try:
                # if the term is already in the dict append the position to the corresponding list
                current_page_index[term][1].append(position)
            except:
                # Add the new term as dict key and initialize the array of positions and add the position
                current_page_index[term]=[doc, array('I',[position])] #'I' indicates unsigned int (int in Python)

        #normalize term frequencies
        # Compute the denominator to normalize term frequencies (formula 2 above)
        # norm is the same for all terms of a document.
        norm = 0
        for term, posting in current_page_index.items():
            # posting will contain the list of positions for current term in current document. 
            # posting ==> [current_doc, [list of positions]] 
            # you can use it to infer the frequency of current term.
            norm += len(posting[1]) ** 2
        norm = math.sqrt(norm)

        # calculate the tf(dividing the term frequency by the above computed norm) and df weights
        for term, posting in current_page_index.items():
            # append the tf for current term (tf = term frequency in current doc/norm)
            tf[term].append(np.round(len(posting[1])/norm,4)) ## SEE formula (1) above
            #increment the document frequency of current term (number of documents containing the current term)
            df[term] += 1 # increment DF for current term

        # Compute IDF following the formula (3) above. HINT: use np.log
        for term in df:
            idf[term] = np.round(np.log(float(num_documents/df[term])), 4)

    return tf, idf


def create_index(corpus):

    """
    Implement the inverted index
    
    Argument:
    lines -- collection of tweets
    
    Returns:
    index - the inverted index (implemented through a Python dictionary) containing terms as keys and the corresponding
    list of documents where these keys appears in (and the positions) as values.

    """
    index = defaultdict(list)
    lines = corpus

    for doc,terms in zip(lines['Id'].values, lines['processed_text'].values):  # Remember, lines contain all documents from file
        ## ===============================================================        
        ## create the index for the current page and store it in current_page_index (current_page_index)
        ## current_page_index ==> { ‘term1’: [current_doc, [list of positions]], ...,‘term_n’: [current_doc, [list of positions]]}
        ## ===============================================================

        current_page_index = {}

        for position, term in enumerate(terms): # terms contains page_title + page_text. Loop over all terms
            try:
                # if the term is already in the index for the current page (current_page_index)
                # append the position to the corresponding list
                current_page_index[term][1].append(position)
            except:
                # Add the new term as dict key and initialize the array of positions and add the position
                current_page_index[term] = [doc, array('I', [position])]  #'I' indicates unsigned int (int in Python)
        # merge the current page index with the main index
        for term_page, posting_page in current_page_index.items():
            index[term_page].append(posting_page)
    return index



def search_in_corpus(corpus, query, index, tf, idf):

    def rank_documents(terms, docs, index, idf, tf, sorted=True):
        """
        Perform the ranking of the results of a search based on the tf-idf weights
        
        Argument:
        terms -- list of query terms
        docs -- list of documents, to rank, matching the query
        index -- inverted index data structure
        idf -- inverted document frequencies
        tf -- term frequencies
        sorted -- if we want that the function returns list ordered or not. Yes, by default.
        
        Returns:
        Print the list of ranked documents and the doc_id and its tf-idf value.
        """

        # I'm interested only on the element of the docVector corresponding to the query terms 
        # The remaining elements would became 0 when multiplied to the query_vector
        doc_vectors = defaultdict(lambda: [0] * len(terms)) # I call doc_vectors[k] for a nonexistent key k, the key-value pair (k,[0]*len(terms)) will be automatically added to the dictionary
        query_vector = [0] * len(terms)
     
        # compute the norm for the query tf
        query_terms_count = collections.Counter(terms)  # get the frequency of each term in the query. 

        query_norm = la.norm(list(query_terms_count.values()))

        for termIndex, term in enumerate(terms):  #termIndex is the index of the term in the query
            if term not in index:
                continue
            ## Compute tf*idf(normalize TF as done with documents)
            query_vector[termIndex] = query_terms_count[term] / query_norm * idf[term]

            # Generate doc_vectors for matching docs
            for doc_index, (doc, postings) in enumerate(index[term]):
                         
                if doc in docs:
                    doc_vectors[doc][termIndex] = tf[term][doc_index] * idf[term]  

        # Calculate the score of each doc 
        # compute the cosine similarity between queyVector and each docVector:
        


        doc_scores = [[np.dot(curDocVec, query_vector), doc] for doc, curDocVec in doc_vectors.items()]
        if sorted:
          doc_scores.sort(reverse=True)
          result_docs = [x[1] for x in doc_scores]
          #print document titles instead if document id's
          #result_docs=[ title_index[x] for x in result_docs ]
          if len(result_docs) == 0:
              print("No results found")
          #print ('\n'.join(result_docs), '\n')
        else:
          result_docs = []



        return result_docs, doc_scores
    
    #index = create_index(corpus) 
    #We will execute this at webpage start to avoid unnecessary compute every time we Search
    query_bt = build_terms(query)
    docs = set()
    for term in query_bt:

        try:
            # store in term_docs the ids of the docs that contain "term"                        
            term_docs = [posting[0] for posting in index[term]]
            
            # docs = docs Union term_docs
            docs |= set(term_docs)
        except:
            #term is not in index
            pass
    docs = list(docs)

    #tf, idf = create_tfidf(corpus)
    #We will execute this at webpage start to avoid unnecessary compute every time we Search

    ranked_docs, aux = rank_documents(query_bt, docs, index, idf, tf)

    return ranked_docs